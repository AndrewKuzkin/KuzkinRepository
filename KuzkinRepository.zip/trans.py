<<<<<<< HEAD
# Программа транспонирует матрицу
print("Транспонирование матрицы")

print("Введите, пожалуйста, количество строк:")
n=int(input())
print("А теперь Введите количество столбцов:")
m=int(input())
print("Сейчас будет сгерерирована матрица размером ", n," на ", m)

     
import random

matrix1=[]
		for i in range(n):
	row=[]
	for j in range(m):
		row.append(random.randint(1, 100))
	
	matrix1.append(row)
print(matrix1)


# Транспонирование матрицы
matrix2=[]
i=0
while(i<m):
	j=0
	row=[]
	while(j<n):
		row.append(matrix1[j][i])
		j=j+1

	matrix2.append(row)
	i=i+1

print("\nА это уже транспонированная матрица")
=======
# Программа транспонирует матрицу
print("Транспонирование матрицы")

print("Введите, пожалуйста, количество строк:")
n=int(input())
print("А теперь Введите количество столбцов:")
m=int(input())
print("Сейчас будет сгерерирована матрица размером ", n," на ", m)

     
import random

matrix1=[]
for i in range(n):
	row=[]
	for j in range(m):
		row.append(random.randint(1, 100))
	
	matrix1.append(row)
print(matrix1)


# Транспонирование матрицы
matrix2=[]
i=0
while(i<m):
	j=0
	row=[]
	while(j<n):
		row.append(matrix1[j][i])
		j=j+1

	matrix2.append(row)
	i=i+1

print("\nА это уже транспонированная матрица")
>>>>>>> 8b0bd27ea0e3030e572e7d54ecdb55af9c8edb03
print(matrix2)